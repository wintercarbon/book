--------------------------------------------------------
--  File created - Thursday-January-19-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence BOOK_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT502"."BOOK_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence INV_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT502"."INV_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence MANAGER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT502"."MANAGER_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence STAFF_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT502"."STAFF_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
--------------------------------------------------------
--  DDL for Sequence SUPPLIER_ID_SEQ
--------------------------------------------------------

   CREATE SEQUENCE  "PROJECT502"."SUPPLIER_ID_SEQ"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;
